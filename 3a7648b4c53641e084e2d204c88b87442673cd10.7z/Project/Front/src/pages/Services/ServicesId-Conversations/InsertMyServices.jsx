import React from "react";

function InsertMyServices({children}){

    return (<>
    {children}
    </>)
}

export default InsertMyServices;