import React from "react";
import InsertMyServices from "./InsertMyServices";

function MyServicesM(){

    console.log('estoy en Myservices')
    return(<>
    <InsertMyServices>
        Inserto mis servicios desde MyServices
    </InsertMyServices>
    </>)
}

export default MyServicesM;