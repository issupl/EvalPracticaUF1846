import React,{useState} from "react";

function Solutioned(props){
    return(<>Estoy en solutioned</>)
}

export default Solutioned;