import React from "react";
import MainApp from "./MainApp";

function IndexApp(){
    return(<MainApp />)
}

export default IndexApp;