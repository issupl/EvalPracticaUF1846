import React from "react";

function ListMessages({children}){

    return (
    <>
    {children}
    </>)
}

export default ListMessages;