import React from 'react';

function TresSeccion({children}) {
  return <div className="">Seccion TRES<div>{children}</div></div>;
}

export default TresSeccion;
