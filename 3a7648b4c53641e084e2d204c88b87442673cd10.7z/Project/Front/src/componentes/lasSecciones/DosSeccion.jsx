import React from 'react';

function DosSeccion({children}) {
  return <div className="">Seccion DOS<div>{children}</div></div>;
}

export default DosSeccion;
