import React from "react";
import HeaderApp from "../HeaderApp";
import Notices from "../losAvisos/Notices";

function HeaderIndexApp(){
    return(<>
    <HeaderApp>
        <Notices />
    </HeaderApp>
    </>)
}

export default HeaderIndexApp;