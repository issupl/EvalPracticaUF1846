import React from "react";

function Component_ServicesId_Conversations_PersonalConversationsId({children}){

  return(<>{children}</>)
}

export default Component_ServicesId_Conversations_PersonalConversationsId;
