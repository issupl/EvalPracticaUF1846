import React from "react";

function Component_ServicesId_Conversations_ColectiveConversationsId(props){

    return (
        <div className="personal-response-wrapper">
            <div className="colocacion">
                <div>
                    imagen
                </div>
                <div>
                    personal response wrapper
                </div>
            </div>
            
        </div>)
}


export default Component_ServicesId_Conversations_ColectiveConversationsId;
