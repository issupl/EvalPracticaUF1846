import React from "react";

function Component_To_Show_Children_Solved_Or_SendSolution({children}){


    return (<>{children}</>)

}

export default Component_To_Show_Children_Solved_Or_SendSolution;