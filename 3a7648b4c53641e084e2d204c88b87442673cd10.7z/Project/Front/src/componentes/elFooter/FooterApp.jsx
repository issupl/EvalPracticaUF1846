import React from "react";

function FooterApp({children}){
    return (<>{children}</>)
}

export default FooterApp;