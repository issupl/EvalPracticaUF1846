const urls = {
  localhost: 'http://localhost:4000'
};

export { urls };
