const endpoints = {
  login: '/users/login/',
  userInsert : '/users/insert/' ,
  services: '/services/',
  deleteServices: '/service/delete/',
  insertComentarioPersonalService:'/users/insert/comentario/personal/service/',
  insertComentarioColectiveService:'/users/insert/comentario/colective/service/',
  readComentarios: '/users/read/allcomments/',
  sendService: '/user/writeService/',
  sendServiceSolution:'/user/service/solution/'
};
export { endpoints };
