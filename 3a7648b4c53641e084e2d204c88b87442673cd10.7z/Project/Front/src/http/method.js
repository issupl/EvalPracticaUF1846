const method = {
  get: 'GET',
  post: 'POST',
  delete: 'DELETE',
  put: 'PUT'
}

export {method};
